from django.contrib import admin
from .models import Student,Teacher,Contact,Register
admin.site.register(Student)
admin.site.register(Teacher)
admin.site.register(Contact)
admin.site.register(Register)

